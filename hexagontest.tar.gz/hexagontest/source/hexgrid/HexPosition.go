package hexgrid

type HexPosition struct {
	Q int `json:"q"`
	R int `json:"r"`
	S int `json:"s"`
}
