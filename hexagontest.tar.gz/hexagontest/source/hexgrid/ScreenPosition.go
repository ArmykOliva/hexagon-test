package hexgrid

type ScreenPosition struct {
	X int `json:"x"`
	Y int `json:"y"`
}
