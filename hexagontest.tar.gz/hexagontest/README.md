
# Hexagon Map Idea

- [ ] Plot nodes on a hexagon map
- [ ] Use cube coordinate system
- [ ] Zoomed out view shows ASNs and hops to ASNs as qrs distance
- [ ] Zoomed in view shows ASN in local perspective (LAN addressed machines)
- [ ] Path planning from/to implies network hops
- [ ] Maybe it makes sense to use qrs for distance of A/B/C IPv4 class subnets?

